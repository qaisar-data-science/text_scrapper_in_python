import sys
import pandas as pd
import requests
import time
from bs4 import BeautifulSoup

url_link = input("Enter URL: ")
element_name = input("Enter Element Name: ")
attr_name = input("Enter Attribute Name: ")
column_name = input("Enter Column Name: ")
file_name = input("Enter File Name: ")

link = requests.get(url_link)
fetchData = []
soupData = BeautifulSoup(link.text, 'html.parser')
loadedData = soupData.find_all(element_name, attrs = attr_name)

time.sleep(2)
for data in loadedData:
    if data not in fetchData:
        fetchData.append(data.text)
        
dataFile = pd.DataFrame({column_name: fetchData})
dataFile.to_csv(f'{file_name}.csv', index = False, encoding = 'utf-8')